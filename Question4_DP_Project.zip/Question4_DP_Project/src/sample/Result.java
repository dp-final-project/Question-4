package sample;

import javafx.beans.property.SimpleStringProperty;

public class Result {
    private String subject;
    private int result;

    public Result(String subject, int result){
        this.subject = subject;
        this.result = result;
    }

    public void setResult(int result) {
        this.result = result;
    }

    public String getSubject() {
        return subject;
    }

    public int getResult() {
        return result;
    }

    public void setSubject(String
                                   subject) {
        this.subject = subject;
    }
}
