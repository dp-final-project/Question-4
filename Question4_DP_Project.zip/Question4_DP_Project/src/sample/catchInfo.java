package sample;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class catchInfo implements Cloneable{
    static Connection connection = null;
    static String database = "schoolpayement";
    static String url ="jdbc:mysql://localhost:3306/" +database;
    static String username = "root";
    static String password ="root";

    static Map<Integer,String> months = new HashMap<>();
    public Map<String,Integer> grade1_4,grade5_8,grade9_12;

//    public Map<String,Integer>gradeKg=new HashMap<String,Integer>();
//    public Map<String,Integer>getGrade1_4=new HashMap<String,Integer>();
//    public Map<String,Integer>getGrade5_8=new HashMap<String,Integer>();
//    public Map<String,Integer>getGrade9_12=new HashMap<String,Integer>();

    static ArrayList<Student> catchedStudentData = new ArrayList<Student>();
    static ArrayList<Payment> catchedPaymentData = new ArrayList<Payment>();
    static ArrayList<GradeKG> catchedGradeKgData = new ArrayList<GradeKG>();
    static ArrayList<Grade1_4> catchedGrade1_4Data = new ArrayList<Grade1_4>();
    static ArrayList<Grade5_8> catchedGrade5_8Data = new ArrayList<Grade5_8>();
    static ArrayList<Grade9_12> catchedGrade9_12Data = new ArrayList<Grade9_12>();


    static Map<Integer,String>subjects = new HashMap<Integer,String>();


    public  void fetchStudentData() throws SQLException{
        connection =DriverManager.getConnection(url, username, password);
        String query ="SELECT * FROM `schoolpayement`. `student`";
        PreparedStatement ps = connection.prepareStatement(query);
        // execute the query, and get a java resultset
        ResultSet rs = ps.executeQuery(query);

        // iterate through the java resultset
        while (rs.next())
        {

            Student student = new Student();



            student.setStudentId(rs.getInt("idstudent"));
            student.setF_name(rs.getString("f_name"));
            student.setL_name(rs.getString("l_name"));
            student.setGrade(rs.getInt("grade"));
            student.setAge(rs.getInt("age"));
            student.setGender(rs.getString("sex"));
            student.setPassword(rs.getString("password"));
            student.setStatus(rs.getBoolean("status"));


            catchedStudentData.add(student);

       }
    }
    public static void fetchPaymentData() throws SQLException{

        connection =DriverManager.getConnection(url, username, password);
        String query ="SELECT * FROM `schoolpayement`. `payment`";
        PreparedStatement ps = connection.prepareStatement(query);
        // execute the query, and get a java resultset
        ResultSet rs = ps.executeQuery(query);

        // iterate through the java resultset
        while (rs.next())
        {

            Payment payment = new Payment();
            payment.setStudentid(rs.getInt("idstudent"));

               // System.out.println("am in fetch payment");
            payment.setPaymentStatus("sep",rs.getBoolean("sep"));
            payment.setPaymentStatus("oct",rs.getBoolean("oct"));
            payment.setPaymentStatus("nov",rs.getBoolean("nov"));
            payment.setPaymentStatus("dec",rs.getBoolean("dec"));
            payment.setPaymentStatus("jan",rs.getBoolean("jan"));
            payment.setPaymentStatus("feb",rs.getBoolean("feb"));
            payment.setPaymentStatus("mar",rs.getBoolean("mar"));
            payment.setPaymentStatus("april",rs.getBoolean("april"));
            payment.setPaymentStatus("may",rs.getBoolean("may"));
            payment.setPaymentStatus("june",rs.getBoolean("june"));



            catchedPaymentData.add(payment);

        }
    }
    public void  fetchgradeKg() throws SQLException {
        connection =DriverManager.getConnection(url, username, password);
        String query ="SELECT * FROM `schoolpayement`. `kg_grade`";
        PreparedStatement ps = connection.prepareStatement(query);
        // execute the query, and get a java resultset
        ResultSet rs = ps.executeQuery(query);

        // iterate through the java resultset
      String kg= "kg";
        while (rs.next())
        {
            GradeKG gradeKG = new GradeKG();

            gradeKG.setNoOfSubjects(5);

            gradeKG.setStu_id(rs.getInt("studentid"));
            gradeKG.setedu_stage(kg);

            gradeKG.setSubjectResult("maths",rs.getInt("maths"));
            gradeKG.setSubjectResult("english",rs.getInt("english"));
            gradeKG.setSubjectResult("amharic",rs.getInt("amharic"));
            gradeKG.setSubjectResult("spoken",rs.getInt("spoken"));
            gradeKG.setSubjectResult("art",rs.getInt("art"));
            catchedGradeKgData.add(gradeKG);

        }

    }
    public void  fetchgrade1_4() throws SQLException {
        connection =DriverManager.getConnection(url, username, password);
        String query ="SELECT * FROM `schoolpayement`. `1_4grade`";
        PreparedStatement ps = connection.prepareStatement(query);
        // execute the query, and get a java resultset
        ResultSet rs = ps.executeQuery(query);

        // iterate through the java resultset
        String kg= "kg";
        while (rs.next())
        {
            Grade1_4 grade1_4 =new Grade1_4();
            grade1_4.setNoOfSubjects(6);

            grade1_4.setStu_id(rs.getInt("idstudent_p1"));
            grade1_4.setedu_stage(kg);

            grade1_4.setSubjectResult("maths",rs.getInt("maths"));
            grade1_4.setSubjectResult("english",rs.getInt("english"));
            grade1_4.setSubjectResult("amharic",rs.getInt("amharic"));
            grade1_4.setSubjectResult("science",rs.getInt("science"));
            grade1_4.setSubjectResult("env_science",rs.getInt("env_science"));
            grade1_4.setSubjectResult("sap_maths",rs.getInt("sap_maths"));
            catchedGrade1_4Data.add(grade1_4);

        }

    }
    public void  fetchgrade5_8() throws SQLException {
        connection =DriverManager.getConnection(url, username, password);
        String query ="SELECT * FROM `schoolpayement`. `5_8grade`";
        PreparedStatement ps = connection.prepareStatement(query);
        // execute the query, and get a java resultset
        ResultSet rs = ps.executeQuery(query);

        // iterate through the java resultset
        String kg= "kg";
        while (rs.next())
        {
          Grade5_8 grade5_8=new Grade5_8();
            grade5_8.setNoOfSubjects(8);

            grade5_8.setStu_id(rs.getInt("idstudent_p2"));
            grade5_8.setedu_stage(kg);

            grade5_8.setSubjectResult("maths",rs.getInt("maths"));
            grade5_8.setSubjectResult("english",rs.getInt("english"));
            grade5_8.setSubjectResult("amharic",rs.getInt("amharic"));
            grade5_8.setSubjectResult("biology",rs.getInt("biology"));
            grade5_8.setSubjectResult("physics",rs.getInt("physics"));
            grade5_8.setSubjectResult("chemistry",rs.getInt("chemistry"));
            grade5_8.setSubjectResult("hp",rs.getInt("hp"));
            grade5_8.setSubjectResult("It_computer",rs.getInt("It_computer"));
            catchedGrade5_8Data.add(grade5_8);

        }

    }
    public void  fetchgrade9_12() throws SQLException {
        connection =DriverManager.getConnection(url, username, password);
        String query ="SELECT * FROM `schoolpayement`. `high_school`";
        PreparedStatement ps = connection.prepareStatement(query);
        // execute the query, and get a java resultset
        ResultSet rs = ps.executeQuery(query);

        // iterate through the java resultset
       String kg= "kg";
        while (rs.next())
        {
           Grade9_12 grade9_12= new Grade9_12();
            grade9_12.setNoOfSubjects(7);

            grade9_12.setStu_id(rs.getInt("studentid_h"));
            grade9_12.setedu_stage(kg);

            grade9_12.setSubjectResult("maths",rs.getInt("maths"));
            grade9_12.setSubjectResult("english",rs.getInt("english"));
            grade9_12.setSubjectResult("amharic",rs.getInt("amharic"));
            grade9_12.setSubjectResult("biology",rs.getInt("biology"));
            grade9_12.setSubjectResult("physics",rs.getInt("physics"));
            grade9_12.setSubjectResult("chemistry",rs.getInt("chemistry"));

            grade9_12.setSubjectResult("it_computer",rs.getInt("it_computer"));
            catchedGrade9_12Data.add(grade9_12);

        }

    }

    public int fetchPassword(int studentid) throws SQLException {
        int returnPassword = 0;
        connection =DriverManager.getConnection(url, username, password);
        String query ="SELECT `password` FROM `schoolpayement`. `student` WHERE `idstudent`="+studentid;
        PreparedStatement ps = connection.prepareStatement(query);

        ResultSet rs = ps.executeQuery(query);
        while (rs.next())
        {
            returnPassword = rs.getInt("password");
        }
        return returnPassword;

    }



    public Object clone(){
        Object clone = null;
        try {
            clone=super.clone();
        }catch (CloneNotSupportedException e){
            e.printStackTrace();
        }
        return clone;}



    public static ArrayList<GradeKG> getCatchedGradeKgData() {
        return catchedGradeKgData;
    }


    public static ArrayList<Grade1_4> getCatchedGrade1_4Data() {
        return catchedGrade1_4Data;
    }

    public static ArrayList<Grade5_8> getCatchedGrade5_8Data() {
        return catchedGrade5_8Data;
    }

    public static ArrayList<Grade9_12> getCatchedGrade9_12Data() {
        return catchedGrade9_12Data;
    }

    public static ArrayList<Payment> getCatchedPaymentData() {
       // System.out.println(" i am in get payment");
        return catchedPaymentData;
    }

    public static ArrayList<Student> getCatchedStudentData() {
        return catchedStudentData;
    }
}
