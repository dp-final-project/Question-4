package sample;

import java.util.ArrayList;
import java.util.Map;

public class State9_12 implements State {
    //Student student = new Student();
    Map<String, Integer> data;
    @Override
    public Map<String, Integer> getresult(GradeInfo gradeInfo, Student student) {
        ArrayList<Grade9_12> grades = catchInfo.getCatchedGrade9_12Data();
        System.out.println(grades);
        for (Grade9_12 g : grades)
            if (g.student_id == student.getStudentId()) {
                data = g.subjects;
            }
        return data;
    }
}
