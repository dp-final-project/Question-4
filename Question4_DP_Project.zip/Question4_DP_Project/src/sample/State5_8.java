package sample;

import java.util.ArrayList;
import java.util.Map;

public class State5_8 implements State {
    //Student student = new Student();
    Map<String, Integer> data;

    @Override
    public Map<String, Integer> getresult(GradeInfo gradeInfo,Student student) {
        ArrayList<Grade5_8> grades = catchInfo.getCatchedGrade5_8Data();
        System.out.println(grades);
        for (Grade5_8 g : grades)
            if (g.student_id == student.getStudentId()) {
                data = g.subjects;
            }
        return data;

    }
}
