package sample;

public class GradeInfo {
    private State state;

    public  GradeInfo(){
        state = null;
    }

    public void setState(State state) {
        this.state = state;
    }
    public State getState(){
        return state;
    }
}
