package sample;

import java.util.Map;

public interface State {
    public Map<String ,Integer> getresult(GradeInfo gradeInfo, Student student);
}
