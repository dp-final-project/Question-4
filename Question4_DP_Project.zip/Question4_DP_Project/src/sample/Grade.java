package sample;



interface  Grade {

//    String edu_stage;
//    HashMap <String,Integer> subjects;// = new HashMap<String ,Integer>();
//    int student_id,noOfSubjects;

    abstract void setStu_id(int student_id);
    abstract void setedu_stage(String edu_stage);
    abstract void setSubjectResult(String subject, int result);
    abstract void setNoOfSubjects(int noOfSubjects);


}