
package sample;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.net.URL;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.omg.Messaging.SYNC_WITH_TRANSPORT;

import static java.lang.Integer.getInteger;
import static sample.Database.insertPayment;
import static sample.Database.insertStudentData;
import static sample.Database.update;


public class Controller implements Initializable {


    static Student student = new Student();
    Database d=Database.getInstance();
    catchInfo catchInfo = new catchInfo();
    Payment payment = new Payment();

    static Random rand = new Random();

    int studentID;
    String thisMonthFull;

    @FXML
    private TableView<Result> assessmentTable;
    @FXML
    private TableColumn<Result, String> subjectColumn;
    @FXML
    private TableColumn<Result,Integer> resultColumn;
    @FXML
    private TableView<Payment> paymentTable;
    @FXML
    private TableColumn<Payment, String> monthColumn;
    @FXML
    private TableColumn<Payment, Boolean> payedColumn;
    @FXML
    private Label firstName;
    @FXML
    private Label lastName;
    @FXML
    private Label studentId;
    @FXML
    private Label gender;
    @FXML
    private Label studentAge;
    @FXML
    private Label grade;


    @FXML
    Button registerBtn;
    @FXML
    TextField fName;
    @FXML
    TextField lName;
    @FXML
    ChoiceBox<String> gradeCBox;
    @FXML
    ChoiceBox<String> ageCBox;
    @FXML
    RadioButton genderM;
    @FXML
    RadioButton genderF;
    @FXML
    PasswordField passwordReg;
    @FXML
    Label currentMonth;


    @FXML
    TextField studentIDPay;
    @FXML
    ChoiceBox<String> paymentMenuCBox;
    @FXML
    TextField accountNo;
    @FXML
    PasswordField passwordPay;
    @FXML
    Button payBtn;

    @FXML
    Label register;

    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    Date now = new Date();
    Login loginPage = new Login();
    public void setStatusTab() throws IOException, SQLException {
        catchInfo.fetchStudentData();
        catchInfo.fetchgradeKg();
        catchInfo.fetchgrade1_4();
        catchInfo.fetchgrade5_8();
        catchInfo.fetchgrade9_12();
        catchInfo.fetchPaymentData();
        loginPage.display();
        int currentStudentId = loginPage.getCurrentStudentId();
        System.out.println("fjdljfdlkjdsljfls" + currentStudentId);
        Student currentStudent = getLoggedInStudent(currentStudentId);
        setStudentInfo(currentStudent);
        setAssessmentTable(currentStudent);
        setPaymentTable(currentStudent);
    }


    public Student getLoggedInStudent(int stud_id) throws SQLException {
        Student logged_in = null;
        ArrayList<Student> students = catchInfo.getCatchedStudentData();
        for (Student d : students) {
            if (d.getStudentId() == stud_id) {
                logged_in = d;
            }
        }
        return logged_in;
    }

    public void setStudentInfo(Student student) {
        firstName.setText(student.getF_name());
        lastName.setText(student.getL_name());
        studentId.setText("" + student.getStudentId());
        studentAge.setText("" + student.getAge());
        gender.setText(student.getGender());
        grade.setText("" + student.getGrade());
    }


    public void setAssessmentTable(Student student) throws SQLException {
        GradeInfo gradeInfo = new GradeInfo();
        int grade = student.getGrade();
        if (grade == 0) {
            StateKg state = new StateKg();
            Map<String,Integer> data = state.getresult(gradeInfo,student);
            populateTable(data);
        }else if( grade >= 1 & grade <= 4 ){
            State1_4 state= new State1_4();
            Map<String,Integer> data = state.getresult(gradeInfo,student);
            populateTable(data);
        }else if( grade >= 5 & grade <= 8 ) {
            State5_8 state= new State5_8();
            Map<String,Integer> data = state.getresult(gradeInfo,student);
            populateTable(data);
        }else{
            State9_12 state= new State9_12();
            Map<String,Integer> data = state.getresult(gradeInfo,student);
            populateTable(data);
        }

    }

    public void populateTable( Map<String, Integer> data){
        ObservableList<Result> resultData = FXCollections.observableArrayList();
        System.out.println("ResultData " + resultData);
        for (Map.Entry<String, Integer> entry : data.entrySet()) {
            resultData.add(new Result(entry.getKey(), entry.getValue()));
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        subjectColumn.setCellValueFactory(new PropertyValueFactory<>("subject"));
        resultColumn.setCellValueFactory(new PropertyValueFactory<>("result"));
        assessmentTable.setItems(resultData);

    }


    public void setPaymentTable(Student student){
        ArrayList<Payment> payments = catchInfo.getCatchedPaymentData();
        for(Payment pay: payments) {
            System.out.println("student id in payment" + pay.getStudentId());
            System.out.println(student.getStudentId());
            if (pay.getStudentId() == student.getStudentId()) {
                System.out.println("PAy.month" );
                Map<String, Boolean> data = pay.months;
                System.out.println("setPaymetmoth" + data);

                populatePayedTable(data);
            }
        }

        }




    public void populatePayedTable( Map<String, Boolean> data){

        ObservableList<Payment> resultData = FXCollections.observableArrayList();
        for (Map.Entry<String, Boolean> entry : data.entrySet()) {
            resultData.add(new Payment(entry.getKey(), entry.getValue()));
        }


        monthColumn.setCellValueFactory(new PropertyValueFactory<>("month"));
        payedColumn.setCellValueFactory(new PropertyValueFactory<>("payed"));
        paymentTable.setItems(resultData);


    }
/**********************************************************REGISTER AND PAYMENT*************************************************/
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            catchInfo.fetchStudentData();
            catchInfo.fetchgradeKg();
            catchInfo.fetchgrade1_4();
            catchInfo.fetchgrade5_8();
            catchInfo.fetchgrade9_12();
            catchInfo.fetchPaymentData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        gradeCBox.setValue("    Grade   ");
        gradeCBox.getItems().addAll("    Grade   ", "KG", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12");
        ageCBox.setValue("    Age    ");
        ageCBox.getItems().addAll( "    Age    ", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20");
        paymentMenuCBox.getItems().addAll("  payment platform    ", "M-Birr", "CBE Birr", "Hello cash", "Amole");
        paymentMenuCBox.setValue("  payment platform    ");

        SimpleDateFormat date = new SimpleDateFormat("MMMM");
        thisMonthFull = date.format(now);
        currentMonth.setText(thisMonthFull);
    }

    public static void main(String[] args) throws SQLException{
        //registerStudent();


    }
    public void registerStudent() throws SQLException {
        System.out.println(fName.getText() + lName.getText() + gradeCBox.getValue() + ageCBox.getValue() + passwordReg.getText() + (genderF.isSelected() || genderM.isSelected()));
        try {
            if (fName.getText() != null && lName.getText() != null && gradeCBox.getValue() != null && ageCBox.getValue() != null && (genderF.isSelected() || genderM.isSelected()) && passwordReg.getText() != null) {

                studentID = rand.nextInt(999) + 100;

                student.setStudentId(studentID);
                student.setF_name(fName.getText());
                student.setL_name(lName.getText());
                if (gradeCBox.getSelectionModel().getSelectedItem() == "KG"){
                    student.setGrade(0);
                }else {
                    student.setGrade(Integer.parseInt(gradeCBox.getSelectionModel().getSelectedItem()));
                }
                student.setAge(Integer.parseInt(ageCBox.getSelectionModel().getSelectedItem()));
                if (genderM.isSelected()) {
                    student.setGender("M");
                } else {
                    student.setGender("F");
                }

                student.setStatus(false);
                student.setPassword(passwordReg.getText());


                d.insertStudentData(student.getStudentId(), student.getF_name(), student.getL_name(), student.getGender(), student.getGrade(), student.getAge(), false, student.getPassword());
                d.insertPayment(student.getStudentId(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
                //add students to grade table String table_name,int studentid,int no_ofSubjects,int[] result
                int[]result = {0, 0, 0, 0, 0, 0, 0, 0};
                if (student.getGrade() == 0) {
                    d.insertResult("kg_grade", student.getStudentId(), 5, result);

                } else if (student.getGrade() <= 4 && student.getGrade() > 0) {
                    d.insertResult("1_4grade", student.getStudentId(), 6, result);

                } else if (student.getGrade() <= 8 && student.getGrade() > 5) {
                    d.insertResult("5_8grade", student.getStudentId(), 8, result);

                } else if (student.getGrade() <= 12 && student.getGrade() > 7) {
                    d.insertResult("high_school", student.getStudentId(), 7, result);
                }
                //insertResult("student", student.getStudentId(), );
                showAlert(student.getF_name() + ", you have successfully registered. Your ID number is: " + studentID);


            } else {
                showAlert("please fill all given fields.");
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public void processPayment() throws SQLException {
        int payID = Integer.parseInt(studentIDPay.getText());
        int PassFromDB = catchInfo.fetchPassword(Integer.parseInt(studentIDPay.getText()));
        if (PassFromDB == Integer.parseInt(passwordPay.getText())) {
            SimpleDateFormat date = new SimpleDateFormat("MMM");

            String thisMonth = date.format(now);
            boolean thisMonStat = false;

            if (thisMonStat) {
                showAlert("Payment alerady paid for this month" + PassFromDB);
            } else {
                d.update("student", payID, "status", 1);
                d.update("payment", payID, thisMonth, 1);
                showAlert("You Have payed this months payment");
                //payment.setPaymentStatus(thisMonthFull, true);

            }
        } else {
            showAlert("Password or ID incorrect.");
        }


    }

    public void showAlert(String message){

        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    
}
