package sample;


import java.util.HashMap;
import java.util.Map;

public class Payment {

    Map<String, Boolean> months = new HashMap<String, Boolean>();

    public int studentId;
    public String month;
    public Boolean payed;

    public Payment(String month, Boolean payed){
        this.month = month;
        this.payed = payed;

    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Boolean getPayed() {
        return payed;
    }

    public String getMonth() {
        return month;
    }

    public Payment(){
        months.put("september", Boolean.FALSE);
        months.put("octber", Boolean.FALSE);
        months.put("november", Boolean.FALSE);
        months.put("december", Boolean.FALSE);
        months.put("january", Boolean.FALSE);
        months.put("feburary", Boolean.FALSE);
        months.put("march", Boolean.FALSE);
        months.put("april", Boolean.FALSE);
        months.put("may", Boolean.FALSE);
        months.put("june", Boolean.FALSE);


    }

    public void setStudentid(int studentId){
        this.studentId=studentId;

    }
    public int getStudentId(){

        return studentId;
    }

    public void setPaymentStatus(String month,boolean status){
        months.put(month, status);

    }
    public boolean getPayStatus(String month){
        return months.get(month);
    }




}