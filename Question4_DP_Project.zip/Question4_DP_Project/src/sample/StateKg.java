package sample;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class StateKg implements State {
    //Student student = new Student();
    Map<String, Integer> data;
    @Override
    public Map<String, Integer> getresult(GradeInfo gradeInfo, Student student) {
        ArrayList<GradeKG> grades = catchInfo.getCatchedGradeKgData();
        System.out.println("Grades " + grades);
        System.out.println(grades);
        for(GradeKG KG: grades)
            if (KG.student_id == student.getStudentId()) {

                System.out.println("subject" + KG.subjects);
                 data = KG.subjects;
                 System.out.println("Statekg"+ data);
            }

        return data;
    }
}
