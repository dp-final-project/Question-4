package sample;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class State1_4 implements State {
    Student student = new Student();
    Map<String, Integer> data;
    @Override
    public Map<String, Integer> getresult(GradeInfo gradeInfo, Student student) {
        ArrayList<Grade1_4> grades = catchInfo.getCatchedGrade1_4Data();
        System.out.println(grades);
        for(Grade1_4 g: grades)
            if (g.student_id == student.getStudentId()) {
                data = g.subjects;
            }
        return data;

    }
}
