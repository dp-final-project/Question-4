package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;


import java.io.IOException;
import java.sql.SQLException;

public class Login {

    catchInfo catchInfo= new catchInfo();
    @FXML TextField loginId;
    @FXML
    PasswordField loginPassword;
    @FXML Label register;
    @FXML Label errorMsg;
    @FXML Button loginBtn;

   public Stage window;
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    static int currentStudentId;

    public void display() throws IOException, SQLException {
        window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Login");

        Parent loginPage = FXMLLoader.load(getClass().getResource("login.fxml"));
        Scene scene = new Scene(loginPage);

        window.setScene(scene);
        window.showAndWait();

        }

 @FXML
    public void validation() throws SQLException {
        Stage stage = (Stage)loginBtn.getScene().getWindow();
     String student_id = loginId.getText().trim();
     String pass_word = loginPassword.getText().trim();
     if (student_id.isEmpty() & pass_word.isEmpty()) {
         errorMsg.setText("Please Enter your Student Id and Password ");
     } else if (student_id.isEmpty()) {
         errorMsg.setText("Please Enter your ID ");
     } else if (pass_word.isEmpty()) {
         errorMsg.setText("Please Enter password ");
     } else {
         int PassFromDB = catchInfo.fetchPassword(Integer.parseInt(student_id));
         int enteredPassword = Integer.parseInt(pass_word);
         if (PassFromDB == enteredPassword) {
             try {
                 setCurrentStudentId(Integer.parseInt(student_id));
                 errorMsg.setText("You have successfully loogged");
                 System.out.println("currentStudent id" + getCurrentStudentId());
                 stage.close();
             }catch (Exception e){
                 showAlert("StudentId must be a number");
             }

         }
     }
    }

    public void showAlert(String message){

        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static int getCurrentStudentId(){
        return currentStudentId;
    }

    public void setCurrentStudentId(int id) {
        this.currentStudentId = id;
    }
}
