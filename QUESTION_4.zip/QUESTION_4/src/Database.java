import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Database {
//static ArrayList<Payment> student_profile = new ArrayList<Payment>();
//static ArrayList<Student> payment = new ArrayList<Student>();

    static Connection connection = null;
    static String database = "";
    static String url ="jdbc:mysql://localhost:3306/" +database;
    static String username = "root";
    static String password ="root";


    public static void insertStudentData(String table_name,int studentId,String fName,String lName,String sex,int grade,int age,boolean status,String password) throws SQLException{

        String query = "INSERT INTO `schoolpayment`.`"+table_name+"`(`idstudent`,`f_name`,`l_name`,`grade`,`age`,`sex`,`status`,`password`) VALUES ("+studentId+",'"+fName+"','"+lName+"',"+grade+","+age+",'"+sex+"',"+status+",'"+password+"'); ";
        executePs(query);}
    public static void insertPayment(int studentId,int sep,int oct,int nov,int dec,int jan,int feb,int mar,int april,int may,int june) throws SQLException{
        String query ="INSERT INTO `schoolpayment`.`payment`(`idstudent`,`sep`,`oct`,`nov`,`dec`,`jan`,`feb`,`mar`,`april`,`may,`june`)VALUES("+studentId+","+sep+","+oct+","+nov+","+dec+","+jan+","+feb+","+mar+","+april+","+may+","+june+"); ";
        executePs(query);

    }
    public static void insertResult(String table_name,int studentid,int no_ofSubjects,int[] result) throws SQLException{
        String queryKg,query1_4,query5_8,query9_12;


        queryKg= "INSERT INTO `schoolpayment`.`"+table_name+"`(`studentid`,`maths`,`english`,`amharic`,`spoken`,`art`) VALUES ("+studentid+","+result[0]+","+result[1]+","+result[2]+","+result[3]+","+result[4]+");";
        query1_4= "INSERT INTO `schoolpayment`.`"+table_name+"`(`studentid`,`maths`,`english`,`amharic`,`science`,`env_science`,`sap_maths`) VALUES ("+studentid+","+result[0]+","+result[1]+","+result[2]+","+result[3]+","+result[4]+","+result[5]+");";
        query5_8= "INSERT INTO `schoolpayment`.`"+table_name+"`(`studentid`,`maths`,`english`,`amharic`,`biology`,`physics`,`chemistry`,`hp`,`it_computer`) VALUES ("+studentid+","+result[0]+","+result[1]+","+result[2]+","+result[3]+","+result[4]+","+result[5]+","+result[6]+","+result[7]+");";
        query9_12="INSERT INTO `schoolpayment`.`"+table_name+"`(`studentid`,`maths`,`english`,`amharic`,`biology`,`physics`,`chemistry`,`it_computer`) VALUES ("+studentid+","+result[0]+","+result[1]+","+result[2]+","+result[3]+","+result[4]+","+result[5]+","+result[6]+");";
        switch(no_ofSubjects){
            case 5: executePs(queryKg);
                break;
            case 6:executePs(query1_4);
                break;
            case 7:executePs(query5_8);
                break;
            case 8:executePs(query9_12);
                break;

        }





    }
    public static void executePs(String query) throws SQLException{
        PreparedStatement ps = connection.prepareStatement(query);
        int status = ps.executeUpdate();
        if(status !=0){

            System.out.println("database connected and  insert data sucessfully");}

    }

    public static void deleteAll(String table_name) throws SQLException {


        String query= "DELETE FROM `schoolpayment`.`"+table_name+"`";

        PreparedStatement ps = connection.prepareStatement(query);
        int status = ps.executeUpdate();
        if(status !=0){

            System.out.println("database connected and deleted");}

    }
    public static void deleteSpecificData(String table_name,int studentid) throws SQLException{
        String query= "DELETE FROM `schoolpayment`.`"+table_name+"`WHERE `id`="+studentid;
        //= "delete from studentdatabase.student where id = ?";
        PreparedStatement ps = connection.prepareStatement(query);
        int status = ps.executeUpdate();
        if(status !=0){

            System.out.println("database connected and deleted");}

    }

    public static void update(String table_name,int studentid,String colName,int value) throws SQLException{
        String query = "UPDATE `schoolpayment`.`"+table_name+"` SET `"+colName+"` ="+ value+" where id ="+ studentid;
        PreparedStatement ps = connection.prepareStatement(query);
        int status = ps.executeUpdate();
        if(status !=0){

            System.out.println("database connected and updated");}

    }
}

