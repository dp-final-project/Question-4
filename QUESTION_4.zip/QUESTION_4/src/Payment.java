import java.util.HashMap;
import java.util.Map;

class Payment {

    Map<String, Boolean> months = new HashMap<String, Boolean>();
    int studentId;
    public Payment(){
        months.put("september", Boolean.FALSE);
        months.put("octber", Boolean.FALSE);
        months.put("november", Boolean.FALSE);
        months.put("december", Boolean.FALSE);
        months.put("january", Boolean.FALSE);
        months.put("feburary", Boolean.FALSE);
        months.put("march", Boolean.FALSE);
        months.put("april", Boolean.FALSE);
        months.put("may", Boolean.FALSE);
        months.put("june", Boolean.FALSE);


    }

    public void setStudentid(int studenId){
        this.studentId=studentId;

    }
    public int getStudentId(){
        return studentId;
    }
    public void setPaymentStatus(String month,boolean status){
        months.put(month, status);

    }
    public boolean getPayStatus(String month){
        return months.get(month);
    }




}