import com.sun.org.apache.xpath.internal.operations.String;

import java.util.HashMap;

public class Grade5_8 implements Grade {

    String edu_stage;
    HashMap<String,Integer> subjects;// = new HashMap<String ,Integer>();
    int student_id,noOfSubjects;

    @Override
    public void setStu_id(int student_id) {
        this.student_id=student_id;
    }

    @Override
    public void setedu_stage(String edu_stage) {
        this.edu_stage=edu_stage;
    }

    @Override
    public  void setSubjectResult(String subject, int result) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        this.subjects.put(subject,result);
    }

    @Override
    public void setNoOfSubjects(int noOfSubjects) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

        this.noOfSubjects = noOfSubjects;

    }

}