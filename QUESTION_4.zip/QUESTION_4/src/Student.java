class Student {
    String f_name,l_name, password, gender;
    int studentId, grade, age;
    boolean status;

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }


    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setF_name(String f_name) {
        this.f_name = f_name;
    }

    public void setL_name(String l_name) {
        this.l_name = l_name;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public void setAge(int age) {
        this.age = age;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getPassword() {
        return password;
    }

    public String getF_name() {
        return f_name;
    }

    public String getL_name() {
        return l_name;
    }

    public String getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public int getStudentId() {
        return studentId;
    }

    public boolean isStatus() {
        return status;
    }

    public int getGrade() {
        return grade;
    }
}