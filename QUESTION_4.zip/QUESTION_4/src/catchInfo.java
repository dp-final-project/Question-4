import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class catchInfo implements Cloneable{
    static Connection connection = null;
    static String database = "";
    static String url ="jdbc:mysql://localhost:3306/" +database;
    static String username = "root";
    static String password ="root";

    static Map<Integer,String> months = new HashMap<>();
    public Map<String,Integer>grade1_4,grade5_8,grade9_12;

//    public Map<String,Integer>gradeKg=new HashMap<String,Integer>();
//    public Map<String,Integer>getGrade1_4=new HashMap<String,Integer>();
//    public Map<String,Integer>getGrade5_8=new HashMap<String,Integer>();
//    public Map<String,Integer>getGrade9_12=new HashMap<String,Integer>();

    static ArrayList<Student> catchedStudentData = new ArrayList<Student>();
    static ArrayList<Payment> catchedPaymentData = new ArrayList<Payment>();
    static ArrayList<GradeKG> catchedGradeKgData = new ArrayList<GradeKG>();
    static ArrayList<Grade1_4> catchedGrade1_4Data = new ArrayList<Grade1_4>();
    static ArrayList<Grade5_8> catchedGrade5_8Data = new ArrayList<Grade5_8>();
    static ArrayList<Grade9_12> catchedGrade9_12Data = new ArrayList<Grade9_12>();


    static Map<Integer,String>subjects = new HashMap<Integer,String>();

    public catchInfo(){
        months.put(1,"sep");
        months.put(2,"oct");
        months.put(3,"nov");
        months.put(4,"dec");
        months.put(5,"jan");
        months.put(6,"feb");
        months.put(7,"mar");
        months.put(8,"april");
        months.put(9,"may");
        months.put(10,"june");

        subjects.put(1,"maths");
        subjects.put(2,"english");
        subjects.put(3,"amharic");


    }



    public  void fetchStudentData() throws SQLException{
        connection =DriverManager.getConnection(url, username, password);
        String query ="SELECT * FROM `studentdatabase`. `student`";
        PreparedStatement ps = connection.prepareStatement(query);
        // execute the query, and get a java resultset
        ResultSet rs = ps.executeQuery(query);

        // iterate through the java resultset
        while (rs.next())
        {

            Student student = new Student();



            student.setStudentId(rs.getInt("idstudent"));
            student.setF_name(rs.getString("f_name"));
            student.setL_name(rs.getString("l_name"));
            student.setGrade(rs.getInt("grade"));
            student.setAge(rs.getInt("age"));
            student.setGender(rs.getString("sex"));
            student.setPassword(rs.getString("password"));
            student.setStatus(rs.getBoolean("status"));


            catchedStudentData.add(student);

       }
    }
    public  void fetchPaymentData() throws SQLException{
        connection =DriverManager.getConnection(url, username, password);
        String query ="SELECT * FROM `studentdatabase`. `payment`";
        PreparedStatement ps = connection.prepareStatement(query);
        // execute the query, and get a java resultset
        ResultSet rs = ps.executeQuery(query);

        // iterate through the java resultset
        while (rs.next())
        {

      Payment payment = new Payment();
      for(int i=1;i<=10;i++){
          payment.setPaymentStatus(months.get(i),rs.getBoolean(months.get(i)));

      }
      payment.setStudentid(rs.getInt("idstudent"));

        }
    }
    public void  fetchgradeKg() throws SQLException {
        connection =DriverManager.getConnection(url, username, password);
        String query ="SELECT * FROM `studentdatabase`. `student`";
        PreparedStatement ps = connection.prepareStatement(query);
        // execute the query, and get a java resultset
        ResultSet rs = ps.executeQuery(query);

        // iterate through the java resultset
        while (rs.next())
        {
            GradeKG gradeKG = new GradeKG();

            gradeKG.setNoOfSubjects(5);
            gradeKG.setStu_id(rs.getInt("studentid"));
            for (int i=1;i<=5;i++){
                //gradeKG.setSubjectResult();
            }
           // gradeKG.setSubjectResult();

        }


    }



    public Object clone(){
        Object clone = null;
        try {
            clone=super.clone();
        }catch (CloneNotSupportedException e){
            e.printStackTrace();
        }
        return clone;}



    public static ArrayList<GradeKG> getCatchedGradeKgData() {
        return catchedGradeKgData;
    }


    public static ArrayList<Grade1_4> getCatchedGrade1_4Data() {
        return catchedGrade1_4Data;
    }

    public static ArrayList<Grade5_8> getCatchedGrade5_8Data() {
        return catchedGrade5_8Data;
    }

    public static ArrayList<Grade9_12> getCatchedGrade9_12Data() {
        return catchedGrade9_12Data;
    }

    public static ArrayList<Payment> getCatchedPaymentData() {
        return catchedPaymentData;
    }

    public static ArrayList<Student> getCatchedStudentData() {
        return catchedStudentData;
    }
}
